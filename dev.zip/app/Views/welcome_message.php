<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
        
        ga('create', 'UA-XXXXX-Y', 'auto');
        ga('send', 'pageview');
    </script>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-WLJ57472LR"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-WLJ57472LR');
    </script>
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="assets/images/fav.ico">
    <title>Fcoin</title>

<!--

Breezed Template

https://templatemo.com/tm-543-breezed

-->
    <!-- Additional CSS Files -->
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">

    <link rel="stylesheet" href="assets/css/templatemo-breezed.css">

    <link rel="stylesheet" href="assets/css/owl-carousel.css">

    <link rel="stylesheet" href="assets/css/lightbox.css">
    
    <link rel="stylesheet" href="assets/css/my-style.css">
    </head>
    
    <body>
    
    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->
    
    
    <!-- ***** Header Area Start ***** -->
    <header class="header-area header-sticky">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <nav class="main-nav">
                        <!-- ***** Logo Start ***** -->
                        <a href="index.html" class="logo my-icon">
                            <img style="background: white; border-radius: 50%;width:50px" src="assets/images/icon/1024x1024fcoin.png" alt="fcoin">
                            FCOIN
                        </a>
                        <!-- ***** Logo End ***** -->
                        <!-- ***** Menu Start ***** -->
                        <ul class="nav">
                            <li class="scroll-to-section"><a href="#getting-started" >Getting Started</a></li>
                            <li class="scroll-to-section"><a href="#about">About</a></li>
                            <li class="scroll-to-section"><a href="#contact-us">Contact</a></li> 
                            <li class="scroll-to-section"><a href="#">Docs</a></li>
                        	<li class="scroll-to-section"><a href="#">Write Paper</a></li>
                        	<li class="scroll-to-section"><a href="https://explorer.fcoin.mg/" target="_blank">EXPLORER DE BLOCK</a></li>
                        	<li class="scroll-to-section"><a href="https://dash.fcoin.mg/">Login</a></li>
                        </ul>        
                        <a class='menu-trigger'>
                            <span>Menu</span>
                        </a>
                        <!-- ***** Menu End ***** -->
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** Header Area End ***** -->
    
    <!-- ***** Search Area ***** -->
    <div id="search">
        <button type="button" class="close">×</button>
        <form id="contact" action="#" method="get">
            <fieldset>
                <input type="search" name="q" placeholder="SEARCH KEYWORD(s)" aria-label="Search through site content">
            </fieldset>
            <fieldset>
                <button type="submit" class="main-button">Search</button>
            </fieldset>
        </form>
    </div>

    <!-- ***** Main Banner Area Start ***** -->
    <div class="main-banner header-text" id="top">
        <div class="Modern-Slider">
         
          <!-- Item -->
          <div class="item">
            <div class="img-fill">
                <img src="assets/images/slide-02.jpg" alt="slide background font">
                <div class="text-content">
                  <h5 class="mb-n1">Fcoin</h5>
                  <h3 class="my-3">THE CRYPTOCURRENCY FOR PAYMENTS AND MONEY TRANSFERT</h3>
                  <h4 class="mt-2 mb-5" style="color:white">Based on Blockchain Technology</h4>
                  <a href="https://github.com/FcoinCrypto/Fcoin/raw/main/Download/fcoin-qt-wallet.zip" class="btn btn-info my-2 mx-1">Downloads Wallet and Tools for Windows</a>
                  <a href="https://github.com/FcoinCrypto/Fcoin/raw/main/Download/ReleaseminerdGui.zip" class="btn btn-success my-2 mx-1">Downloads Fcoin-ming Tools for Windows</a>
                </div>
            </div>
          </div>
          <!-- // Item -->
        </div>
    </div>
    <!-- ***** Main Banner Area End ***** -->
        <!-- ***** Features Big Item Start ***** -->
        <section class="section mt-3" id="getting-started">
            <div class="container-fluid">
                <h6 class="my-weight my-green-title">Getting Started</h6>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <div class="section-heading">
                            
                            <img src="https://raw.githubusercontent.com/Ericnirina/Accueil-Fcoin/master/assets/images/fcoin_logo.png"  style="width: 60%;" class="fcoin-left" alt="fcoin">
                            <h2>What is Fcoin?</h2>
                        </div>
                        <div class="subscribe-content">
                            <p class="text-justify">Fcoin is a peer-to-peer internet currency, which allows instant payments, with near zero costs to anyone in the world. Fcoin is an open source global payment network, which is fully decentralized with no central authorities. Users can now control their own finances, secured by a system based entirely on mathematics. Compared to Bitcoin, Fcoin sans transactions are faster to confirm and have higher storage efficiency. Due to its use by the industry, the volume of exchange and the liquidity on the exchange markets, Fcoin is a complementary means of commerce to Bitcoin, which has proven its worth.</p>
                        </div>
                    </div>
                    <div class="col-lg-8 offset-lg-2">
                        <div class="section-heading">
                            <h2>1. Setting Up a New Wallet</h2>
                        </div>
                        <div class="subscribe-content">
                            <p>There are multiple types of wallets you can use with Fcoin.

                                To view a list of them, their interface and a brief description, as a well as guides on how to use them, you can check this guide.</p>
                        </div>
                    </div>

                    <div class="col-lg-8 offset-lg-2">
                        <div class="section-heading">
                            <h2>2. Start Mining Fcoin</h2>
                        </div>
                        <div class="subscribe-content">
                            <p>Mining is essentially the process of using your computer to help verify and secure a cryptocurrency network, in our case, it is the Fcoin network. By doing this, you will be rewarded with Fcoin.

                                If you want to learn about cryptocurrencies, mining is a great place to start!
                                
                                To view an in-depth guide on how to mine Fcoin, you can view <a href="https://fcoin.mg/guides/mining/Mining">this guide</a></p>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        <!-- ***** Features Big Item End ***** -->
    
    <!-- ***** About Area Starts ***** -->
    <section class="section" style="margin-top: -50px;" id="about">
        <div class="container-fluid">
            <div class="section-heading">
                <h6>About Us</h6>
            </div>
            <div class="row mb-4">
                <div class="col-lg-6 col-md-6 col-xs-12">
                    <div class="left-text-content">
                        <h5 class="h-margin">
                            <a class="anchor" aria-hidden="true" id="how-and-why-was-fcoin-created"></a>
                            <a href="#how-and-why-was-fcoin-created" aria-hidden="true" class="hash-link">
                                <svg class="hash-link-icon" aria-hidden="true" height="16" version="1.1" viewBox="0 0 16 16" width="16">
                                    <path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"></path>
                                </svg>
                            </a>How and Why was Fcoin Created?
                        </h5>
                        <p>Fcoin was officially created on July 12, 2022 by RANDRIANASOLO Mamy and GeekMada.</p>
                        <p>It was born from the idea that we could change the ecosystem of a developing country thanks to blockchain technology.</p>
                        <p>Its objective is to create all the added value of the country by structuring the economy around the technology of smart contracts. We strongly believe in our strategy and the added value will create itself once the momentum unfolds.</p>
                        <p>Fcoin was created with <strong>Yes</strong> Pre-Mine, <strong>Yes</strong>  ongoing ICO.</p>
        
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-xs-12">
                    <div>
                        <h5 class="h-margin"><a class="anchor" aria-hidden="true" id="our-background"></a><a href="#our-background" aria-hidden="true" class="hash-link"><svg class="hash-link-icon" aria-hidden="true" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"></path></svg></a>Our Background</h5>
                        <p>Our journey
                        Most of us are full-time contractors and developers on other projects.</p>
                        <p>We also have a wide range of people in the community, people from all walks of life who contribute to the community in one way or another.</p>
                        <p>Our community and development team is growing week by week and that's what makes the Fcoin community so great and exceptional!</p>
                
                    </div>
                    
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-6 col-xs-12">
                    <div class="left-text-content">
                        
                        <div class="row">
                            <div class="col-md-12 col-sm-12">
                                    <img src="assets/images/icon/fpay.png" style='width:100%' alt="fpay">
                                    
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-xs-12 mt-1">
                    <div>
                        <h2>FPay</h2>

                        <p style="font-size: 1rem; margin-bottom: 1%;">Fcoin is a fast, easy and private cryptocurrency which allows you to send money to friends and businesses. </p>
                        <p style="font-size: 1rem; margin-bottom: 1%;">One of Fcoin's main goals is to make things as simple and as accessible as possible for everyday people, creating a cryptocurrency which is inviting, fun, and friendly.</p>
                        <p style="font-size: 1rem; margin-bottom: 1%;">FPay is a powerful, easy-to-use, multi-channel payment solution.</p>
    
                    </div>
                    
                </div>
            </div>
           
            

        </div>
    </section>
    <!-- ***** About Area Ends ***** -->

    <!-- ***** Features Big Item Start ***** -->
    <section class="section" id="features">
        <div class="container-fluid">
            <div class="row my-flex">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6" data-scroll-reveal="enter left move 30px over 0.6s after 0.4s">
                    <div class="features-item">
                        <div class="features-icon">
                            <img src="assets/images/svg/undraw_community.svg" alt="undraw" style='width:20%; height:20%'>
                        </div>
                        <div class="features-content">
                            <h4>Documentation</h4>
                            <p>crypto-currency can be defined as a digital currency that is exchanged peer-to-peer, i.e. in a decentralized way, without an intermediary, thanks to an encrypted procedure on a blockchain.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6" data-scroll-reveal="enter right move 30px over 0.6s after 0.4s">
                    <div class="features-item">
                        <div class="features-icon">
                            <img src="assets/images/svg/contributing.svg" alt="contributing" style='width:20%; height:20%'>
                        </div>
                        <div class="features-content">
                            <h4>Contributing</h4>
                            <p>Information on contributing to Fcoin</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Features Big Item End ***** -->



    <!-- ***** Projects Area Starts ***** -->
    <section class="section" id="projects" style="margin-top: -200px;">
      <div class="container">
        <div>
            <div id="fcoin" class="mg-bottom">
                <div >
                    <h1>About</h1>
                    
                    <p>Fcoin's code is forked from the Bytecoin code, and it has majorly the same privacy features you'll find in Monero and Aeon. Every transaction is private, by default.</p>
                    <p>Some of the main features of Fcoin include:</p>
                    <ul>
                    <li><p>On-chain privacy</p></li>
                    <li><p>Only two decimal places</p></li>
                    <li><p>Fast transactions</p></li>
                    <li><p>User-centric developers</p></li>
                    <li><p>Easy to mine</p></li>
                    <li><p>Easy to use</p></li>
                    <li><p>Amazing community</p></li>
                    <li><p>Send to anyone, around the world</p></li>
                    </ul>
                    <p>To learn more about us, check out our other various articles, describing:</p>
                    <ul>
                    <li><p><a href="#how-and-why-was-fcoin-created">Our Background and History</a></p></li>
                    <li><p><a href="#contributors">Our Community</a></p></li>
                    <li><p><a href="#contributing">How to Contribute</a></p></li>
                    <li><p><a href="#Technical-Data">its Technical Data</a></p></li>
                    <li><p><a href="#timeline">Our Timeline</a></p></li>
                    </ul>
                    <p>We recommend you check em out, to get acquainted with Fcoin!</p>
                </div>
            </div>

                <div id="contributing" class="mg-bottom">
                    <h1>Contributing</h1>
                    <div><p>To help contribute and improve the Fcoin project, you can:</p>
                    <ul>
                    <li><p>submit pull requests, or create issues over at our <a href="https://github.com/Fcoin/Fcoin">GitHub Repo</a>.</p></li>
                    <li><p>help improve this wiki by submitting a pull request/making an issue over at its <a href="https://github.com/Fcoin/Fcoin">GitHub Repo</a>.</p></li>
                    <li><p>help make various tools which need to be refined/be worked on (wallets, daemons etc.).
                    Check the <a href="https://github.com/Fcoin/Fcoin">GitHub Repo</a> for more information.</p></li>
                    </ul>
                </div>
            </div>

            <div id="Technical-Data" class="mg-bottom">
                <h1>Technical Data</h1>
                <div><p>Name : Fcoin</p>
                <p>Public address letter : <code>F</code></p>
                <p>Public address letter testnet : <code>M</code></p>
                <p>RPC port : <code>7849</code></p>
                <p>P2P port : <code>7850</code></p>
                <p>Block reward : <code>50 coins</code></p>
                <p>Block halving : <code>925000</code> blocks</p>
                <p>Algorithm : <a href="https://en.wikipedia.org/wiki/Scrypt">Scrypt Proof of Work</a></p>
                <p>Coin abbreviation : <code>FTC</code></p>
                <p>Block time : <code>30</code> second target block time - made by and for miners.</p>
                <p>Decimal places : Two decimal places, like MGA</p>
                <p>Supply Cap : <code>103,600,0001</code></p>
                <p>Premine : <code>10600000</code> coins</p>
                <p>Website URL : <a href="https://fcoin.mg/">https://fcoin.mg/</a></p>
                <p>Address Prefix : <code>FTC</code></p>
                <p>Currency Code : <code>FTC</code></p>
                </div>
            </div>

            <div id="timeline" class="mg-bottom">
                <h1>Timeline</h1>
                <div><p>This is a timeline dedicated to important dates in the history of Fcoin.</p>
                <ul>
                <li><p>July 12, 2022 : creation of the Fcoin blockchain</p></li>
                <li><p>September 02, 2022 : official pre-launch of Fcoin</p></li>
                <li><p>September 15, 2022 : Sale on the exchange dex-trade.com and our site fcoin.mg</p></li>
                <li><p>October 1, 2022 : massive recruitment of the Fcoin team</p></li>
                <li><p>November 1, 2022 : Fcoin ICO</p></li>
                <li><p>December 1  2022 : Market Cap, 2,000,000 Fcoin</p></li>
                <li><p>January 1, 2022 : launch of APP Smart Contracts</p></li>
                <li><p>February 1, 2023 : Market Cap, 10,000,000 Fcoin</p></li>
                <li><p>March 1, 2023 : fork of Fcoin for the implementation of <a href="https://github.com/ltc-mweb/libmw">libmw</a> in the Blockchain Fcoin</p></li>
                <li><p>July 1, 2023 : creation of the first Fcoin Tokens</p></li>
                </ul>
            </div>
            </div>
            <div id="contributors" class="mg-bottom">
                <h1>Contributors</h1>
                <div><p>Huge thank you to everyone here, they've made major commits to the wiki and helped make it what it is today!</p>
                <ul>
                <li>@Fanampiana</li>
                <li>@AceTeaC</li>
                <li>@NetDevAgency</li>
                <li>@GeekMada</li>
                </ul>
                <p>And, of course-</p>
                <ul>
                <li>the Fcoin Community</li>
                </ul>
            </div>
            </div>
        </div>
      </div>
    </section>
    <!-- ***** Projects Area Ends ***** -->

    
    <!-- ***** Contact Us Area Starts ***** -->
    <section class="section" id="contact-us">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-xs-12">
                    <div class="left-text-content">
                        <div class="section-heading">
                            <h6>Contact Us</h6>
                            <h2>Feel free to keep in touch with us!</h2>
                        </div>
                        <ul class="contact-info">
                            <li><img src="assets/images/contact-info-01.png" alt="numero">+261 38 39 890 16</li>
                            <li><img src="assets/images/contact-info-02.png" alt="mail">contact@fcoin.mg</li>
                            <li><img src="assets/images/contact-info-03.png" alt="site">www.fcoin.mg</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-8 col-md-8 col-xs-12">
                    <div class="contact-form">

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Contact Us Area Ends ***** -->
    
    <!-- ***** Footer Start ***** -->
    <footer>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-8 col-xs-8">
                    <div class="left-text-content">
                        <div class="container-fluid">
                            <section class="sitemap row">
                                <a href="/" class="nav-home">
                                    <img style="background-color: white; border-radius: 50%;" src="assets/images/icon/1024x1024fcoin.png" alt="Fcoin " width="66" height="58">
                                </a>
                                <div class="col-lg-3 col-xs-3 my-2">
                                    <h5>Docs</h5>
                                    <a href="#getting-started">Getting Started</a><br>
                                    <a href="https://fcoin.mg/guides/mining/Mining">Guides</a><br>
                                    <a href="#">Developer Resources</a>
                                </div>
                                <div class="col-lg-3 col-xs-3 my-2">
                                    <h5>Community</h5>
                                    <a href="https://discord.com/invite/94trf6G2mQ">Discord Chat</a><br>
                                    <a href="https://reddit.com/r/FTC/">Reddit</a><br>
                                </div>
                                <div class="col-lg-4 col-xs-4 my-2">
                                    <h5>Terms and conditions</h5>
                                    <a href="#">Terms of Sales</a><br>
                                    <a href="#">Terms of Service</a><br>
                                    <a href="#">Privacy Policy</a><br>
                                </div>
                            </section>
                            
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-xs-4 mt-2">
                        <div class="right-text-content">
                                <ul class="social-icons">
                                    <li><p>Follow Us</p></li>
                                    <li><a rel="nofollow" target="_blank" href="https://www.facebook.com/fcoincrypto"><img src="assets/images/icon/logo-fb_full.png"  alt="facebook" style='width:100%'></a></li>
                                    <li><a rel="nofollow" target="_blank" href="https://discord.com/invite/94trf6G2mQ"><img src="assets/images/icon/Discord-emblem.jpg" class="br-radius" alt="discord" style='width:100%'></a></li>
                                    <li><a rel="nofollow" target="_blank" href="https://t.me/FCoin"><img src="assets/images/icon/Telegram_logo.svg.png" class="br-radius" alt="telegram" style='width:80%'></a></li>
                                    <li><a rel="nofollow" target="_blank" href="https://twitter.com/CryptoFcoin"><img src="assets/images/logo_twitter.png" class="br-radius" alt="twitter" style='width:80%'></a></li>
                        		</ul>
                        </div>
                </div>
            </div>
            <div class="container-fluid mt-footer">
                <div class="column"> 
                    <p style="margin-bottom: 3%;"></p>                       
                    <p style="color: black;margin-bottom:-1%;">Copyright © 2022 Fcoin</p>
                    <p style="color: black;margin-bottom:-1%;">Docs released under the  <a href="https://opensource.org/licenses/MIT">MIT License</a></p>
                    <p style="color: black; margin: 0;">Fcoin released under the  <a href="https://www.gnu.org/licenses/gpl-3.0.html">GNU General Public V3 License</a></p>
                </div>
            </div>
        </div>
    </footer>
    

    <!-- jQuery -->
    <script src="assets/js/jquery-2.1.0.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/js/popper.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Plugins -->
    <script src="assets/js/owl-carousel.js"></script>
    <script src="assets/js/scrollreveal.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/imgfix.min.js"></script> 
    <script src="assets/js/slick.js"></script> 
    <script src="assets/js/lightbox.js"></script> 
    <script src="assets/js/isotope.js"></script> 
    
    <!-- Global Init -->
    <script src="assets/js/custom.js"></script>

    <script>

        $(function() {
            var selectedClass = "";
            $("p").click(function(){
            selectedClass = $(this).attr("data-rel");
            $("#portfolio").fadeTo(50, 0.1);
                $("#portfolio div").not("."+selectedClass).fadeOut();
            setTimeout(function() {
              $("."+selectedClass).fadeIn();
              $("#portfolio").fadeTo(50, 1);
            }, 500);
                
            });
        });

    </script>

  </body>
</html>